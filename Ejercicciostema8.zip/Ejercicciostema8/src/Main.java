// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Persona persona = new Persona();

        persona.setNombre("SpiderMan");
        persona.setEdad(23);
        persona.setTelefono(999999999);

        String nombre = persona.getNombre();
        int telefono = persona.getTelefono();
        int edad = persona.getEdad();


        System.out.println("nombre " + nombre + " edad " + edad + " telefono " + telefono  );
    }
}

class Persona {
    private int telefono;
    private int edad;
    private String nombre;


    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setEdad(int edad){
        this.edad = edad;
    }
    public void setTelefono(int telefono){
        this.telefono = telefono;
    }

    public String getNombre(){
        return this.nombre;
    }
    public int getEdad(){
        return this.edad;

    }
    public int getTelefono(){
        return this.telefono;
    }
}