
public class Main {
    public static void main(String[] args) {

    Cliente cliente = new Cliente();
    cliente.edad = 34;
    cliente.telefono = 983992323;
    cliente.Nombre = "alfredo";
    cliente.credito = 20000;
    System.out.println("Cliente: Nombre " + cliente.Nombre + " edad " + cliente.edad + " telefono " + cliente.telefono + " credito " + cliente.credito );

        Trabajador trabajador = new Trabajador();
        trabajador.edad = 34;
        trabajador.telefono = 983992323;
        trabajador.Nombre = "alfredo";
        trabajador.salario = 8000;
        System.out.println("Trabajador: Nombre " + trabajador.Nombre + " edad " + trabajador.edad + " telefono " + trabajador.telefono + " salario " + trabajador.salario );
    }
}

class Persona {
    int edad;
    int telefono;
    String Nombre;



}

class Cliente extends Persona {

    int credito;
}


class Trabajador extends Persona {
    int salario;
}