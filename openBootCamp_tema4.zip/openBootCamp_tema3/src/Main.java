// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int numero = -3;

                if(numero == 0) {
                    System.out.println(("es cero"));
                } else if (numero > 0) {
                    System.out.println("es positivo");
                } else {
                    System.out.println("es negativo");
                }

        int numeroWhile = 0;
                    System.out.println(numeroWhile);
                while (numeroWhile < 3){
                    System.out.println(numeroWhile);
                    numeroWhile = numeroWhile +1;
                }
        int numeroDoWhile = 3;

                do {
                    System.out.println(numeroDoWhile);
                    numeroDoWhile = numeroDoWhile +1;
                }while (numeroDoWhile < 3);

        for (int numeroFor = 0;  numeroFor <= 3 ; numeroFor++) {
            System.out.println(numeroFor);
        }

        String estacion = "verano";

        switch (estacion) {
            case "verano":
                System.out.println("es Verano");
                break;
            case "Primavera":
                System.out.println("es Primavera");
                break;
            case "Otoño":
                System.out.println("es Otoño");
                break;
            default:
                System.out.println("es invierno");
        }

    }

}